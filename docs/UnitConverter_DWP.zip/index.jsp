<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//OMA//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<%@ page language="java" 
		 contentType="text/html; charset=UTF-8"
		 pageEncoding="UTF-8"
		 import="unit.UnitNames"
%><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Topic</title>
</head>
<body>
<a href="../info/menu.jsp" id="softkey-back"></a>
<ul>
<%
	// loading topics...
	String[] topics = UnitNames.getTopics();

	// writing topics in menu...
	for(int i=0;i<topics.length;i++) {
		out.println("<li><a href=\"convertfrom.jsp?topic=" + i + "\">" + topics[i] + "</a></li>");
	}
%>
</ul>
</body>
</html>