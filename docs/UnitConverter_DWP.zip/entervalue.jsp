<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//OMA//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<%@ page language="java" 
		 contentType="text/html; charset=UTF-8"
		 pageEncoding="UTF-8"
		 import="unit.UnitNames"
%><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unit Converter</title>
</head>
<body>
<%
	//getting parameters...
	int topic,from,to;
	try {
		topic = Integer.parseInt(request.getParameter("topic"));
		from = Integer.parseInt(request.getParameter("from"));
		to = Integer.parseInt(request.getParameter("to"));
	} catch (NumberFormatException e) {
		topic = 0;
		from = 0;
		to = 0;
	}
%>
<!-- creating a form for input value -->
<form method="get" action="result.jsp" accept-charset="UTF-8">
<p>Enter quantity:</p>
<input type="text" name="value" maxlength="15"/>
<input type="hidden" name="topic" value="<%=topic %>"/>
<input type="hidden" name="from" value="<%=from %>"/>
<input type="hidden" name="to" value="<%=to %>"/>
<input type="submit" value="Convert"/>
</form>
</body>
</html>