<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//OMA//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<%@ page language="java" 
		 contentType="text/html; charset=UTF-8"
		 pageEncoding="UTF-8"
		 import="unit.UnitNames,
		 		 javax.measure.unit.*,
		 		 javax.measure.converter.UnitConverter"
%><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Result</title>
</head>
<body>
<%
	//loading topics and units...
	String[] topics = UnitNames.getTopics();
	String[][] units = UnitNames.getUnits();
	
	//getting parameters...
	int topic,from,to;
	try {
		topic = Integer.parseInt(request.getParameter("topic"));
		from = Integer.parseInt(request.getParameter("from"));
		to = Integer.parseInt(request.getParameter("to"));
	} catch (NumberFormatException e) {
		topic = 0;
		from = 0;
		to = 0;
	}

	//getting value
	String _value = request.getParameter("value");	
	double value=0;
	boolean input=true;
	
	//checking value
	if (_value != null) {
		if (_value.contains(",")) {
			_value = _value.replace(',','.');
		}
		if (topic != 10) {
			try {
				value = Double.parseDouble(_value);
				input = true;
			} catch(Exception e) {
				input = false;
			}
		}
	}
	else {
		input = false;
	}
	
	if (input == true) {
		
		//creating two units <javax.measure.unit.Unit>
		Unit<?> unitfrom = null;
		Unit<?> unitto = null;
		
		//numberfrom, numberto, and numerals(boolean) are needed for numerals
		int numberfrom = 0;
		String numberto = null;	 
		boolean numerals = true;
	 
	 	//shoe is needed for shoe size
	 	double shoe = 0;
	 	
	 	/* 
		 * switch-case
		 * first 'topic' is switched - in it 'from' and 'to' are switched
		 * 'unitfrom' and 'unitto' are defined with their SI-units
		 * <javax.measure.unit.SI> and <javax.measure.unit.NonSI>
		 */	 
		 
		switch(topic) {
		case 0:
			switch(from) {
			case 0:
				unitfrom = SI.MILLIMETER;			// millimetre
				break;
			case 1:
				unitfrom = SI.CENTIMETER;			// centimetre
				break;
			case 2:
				unitfrom = SI.METER;				// metre
				break;
			case 3:
				unitfrom = SI.KILOMETER;			// kilometre
				break;
			case 4:
				unitfrom = NonSI.INCH;				// inch
				break;
			case 5:
				unitfrom = NonSI.FOOT;				// foot
				break;
			case 6:
				unitfrom = NonSI.YARD;				// yard
				break;
			case 7:
				unitfrom = NonSI.MILE;				// mile
				break;
			case 8:
				unitfrom = NonSI.NAUTICAL_MILE;		// nautical mile
				break;
		 	}
		 	switch(to) {
		 	case 0:
		 		unitto = SI.MILLIMETER;
		 		break;
		 	case 1:
		 		unitto = SI.CENTIMETER;
		 		break;
		 	case 2:
		 		unitto = SI.METER;	 		
		 		break;
		 	case 3:
		 		unitto = SI.KILOMETER;
		 		break;
		 	case 4:
		 		unitto = NonSI.INCH;
		 		break;
		 	case 5:
		 		unitto = NonSI.FOOT;
		 		break;
		 	case 6:
		 		unitto = NonSI.YARD;
		 		break;
		 	case 7:
		 		unitto = NonSI.MILE;
		 		break;
		 	case 8:
		 		unitto = NonSI.NAUTICAL_MILE;
		 		break;
		 	}
		 	break;
		 	
		case 1:
			switch(from) {
			case 0:
				unitfrom = SI.SQUARE_METRE.divide(1000000);						// square millimetre
				break;
			case 1:
				unitfrom = SI.SQUARE_METRE.divide(10000);						// square centimetre
				break;
			case 2:
				unitfrom = SI.SQUARE_METRE;										// square metre
				break;
			case 3:
				unitfrom = NonSI.ARE;											// ar
				break;
			case 4:
				unitfrom = NonSI.HECTARE;										// hectar
				break;
			case 5:
				unitfrom = SI.SQUARE_METRE.divide((double)0.000001);					// square kilometre
				break;
			case 6:
				unitfrom = SI.SQUARE_METRE.divide((double)1/0.00064516);		// square inch
				break;
			case 7:
				unitfrom = SI.SQUARE_METRE.divide((double)1/0.09290304);		// square foot
				break;
			case 8:
				unitfrom = SI.SQUARE_METRE.divide((double)1/0.83612736);		// square yard
				break;
			case 9:
				unitfrom = SI.SQUARE_METRE.divide((double)1/2589988.110336);	// square mile
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.SQUARE_METRE.divide(1000000);
				break;
			case 1:
				unitto = SI.SQUARE_METRE.divide(10000);
				break;
			case 2:
				unitto = SI.SQUARE_METRE;
				break;
			case 3:
				unitto = NonSI.ARE;
				break;
			case 4:
	 			unitto = NonSI.HECTARE;
	 			break;
	 		case 5:
	 			unitto = SI.SQUARE_METRE.divide((double)0.000001);
	 			break;
	 		case 6:
	 			unitto = SI.SQUARE_METRE.divide((double)1/0.00064516);
	 			break;
	 		case 7:
	 			unitto = SI.SQUARE_METRE.divide((double)1/0.09290304);
	 			break;
	 		case 8:
	 			unitto = SI.SQUARE_METRE.divide((double)1/0.83612736);
	 			break;
	 		case 9:
	 			unitto = SI.SQUARE_METRE.divide((double)1/2589988.110336);
	 			break;
	 		}
		 	break;
		 	
		case 2:
			switch(from) {
			case 0:
				unitfrom = SI.CUBIC_METRE.divide(1000000000);						// cubic millimetre
				break;
			case 1:
				unitfrom = SI.CUBIC_METRE.divide(1000000);							// cubic centimetre
				break;
			case 2:
				unitfrom = SI.CUBIC_METRE;											// cubic metre
				break;
			case 3:
				unitfrom = SI.CUBIC_METRE.divide(1000000);							// millilitre
				break;
			case 4:
				unitfrom = NonSI.LITRE;												// litre
				break;
			case 5:
				unitfrom = NonSI.OUNCE_LIQUID_UK ;									// UK fluid oz
				break;
			case 6:
				unitfrom = NonSI.CUBIC_INCH.divide((double)1/34.67743125);			// UK pint
				break;
			case 7:
				unitfrom = NonSI.LITRE.divide((double)1/1.1365225704987);			// UK quart
				break;
			case 8:
				unitfrom = NonSI.GALLON_UK;											// UK gallon
				break;
			case 9:
				unitfrom = NonSI.OUNCE_LIQUID_US ;									// US fluid oz
				break;
			case 10:
				unitfrom = NonSI.CUBIC_INCH.divide((double)1/28.875);				// US pint
				break;
			case 11:
				unitfrom = NonSI.LITRE.divide((double)1/0.946352946);				// US quart
				break;
			case 12:
				unitfrom = NonSI.GALLON_LIQUID_US;				 					// US gallon
				break;
			case 13:
				unitfrom = NonSI.GALLON_LIQUID_US.divide((double)1/42);				// barrel (oil)
				break;
		 	}
		 	switch(to) {
		 	case 0:
		 		unitto = SI.CUBIC_METRE.divide(1000000000);
		 		break;
	 		case 1:
	 			unitto = SI.CUBIC_METRE.divide(1000000);
	 			break;
	 		case 2:
	 			unitto = SI.CUBIC_METRE;
	 			break;
	 		case 3:
	 			unitto = SI.CUBIC_METRE.divide(1000000);
	 			break;
	 		case 4:
	 			unitto = NonSI.LITRE;
	 			break;
	 		case 5:
	 			unitto = NonSI.OUNCE_LIQUID_UK ;									// UK fluid oz
	 			break;
	 		case 6:
	 			unitto = NonSI.CUBIC_INCH.divide((double)1/34.67743125);			// UK pint
	 			break;
	 		case 7:
	 			unitto = NonSI.LITRE.divide((double)1/1.1365225704987);				// UK quart
	 			break;	
	 		case 8:
	 			unitto = NonSI.GALLON_UK;											// UK gallon
	 			break;
	 		case 9:
	 			unitto = NonSI.OUNCE_LIQUID_US ;									// US fluid oz
	 			break;
	 		case 10:
	 			unitto = NonSI.CUBIC_INCH.divide((double)1/28.875);					// US pint
	 			break;
	 		case 11:
	 			unitto = NonSI.LITRE.divide((double)1/0.946352946);					// US quart
	 			break;
	 		case 12:
	 			unitto = NonSI.GALLON_LIQUID_US;				 					// US gallon
	 			break;
	 		case 13:
	 			unitto = NonSI.GALLON_LIQUID_US.divide((double)1/42);				// barrel (oil)
	 			break;
	 		}
		 	break;
		 	
		case 3:
			switch(from) {
			case 0:
				unitfrom = SI.METRES_PER_SECOND;		// Meter/Second
				break;
			case 1:
				unitfrom = NonSI.KILOMETRES_PER_HOUR;	// Kilometers/Hour
				break;
			case 2:
				unitfrom = NonSI.MILES_PER_HOUR;		// Miles/Hour
				break;
			case 3:
				unitfrom = NonSI.KNOT;					// Knots
				break;		
		 	}
			switch(to) {
			case 0:
				unitto = SI.METRES_PER_SECOND;
				break;
			case 1:
				unitto = NonSI.KILOMETRES_PER_HOUR;
				break;
			case 2:
				unitto = NonSI.MILES_PER_HOUR;
				break;
			case 3:
				unitto = NonSI.KNOT;
				break;
			}
			break;
			
		case 4:
			switch(from) {
			case 0:
				unitfrom = SI.GRAM.divide(1000);		// milligramm
				break;
			case 1:
				unitfrom = SI.GRAM;						// gramm
				break;
			case 2:
				unitfrom = SI.KILOGRAM;					// kilogramm
				break;
			case 3:
				unitfrom = NonSI.METRIC_TON;			// metric ton
				break;
			case 4:
				unitfrom = NonSI.TON_US;				// Short ton (US)
				break;
			case 5:
				unitfrom = NonSI.TON_UK;				// Long ton (UK)
				break;
			case 6:
				unitfrom = SI.GRAM.divide((double)1/500);		// pound (german)
				break;
			case 7:
				unitfrom = NonSI.OUNCE;					// ounce
				break;
			case 8:
				unitfrom = NonSI.POUND;					// pound
				break;
			case 9:
				unitfrom = NonSI.POUND.divide((double)1/14);	// stone
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.GRAM.divide(1000);
				break;
			case 1:
				unitto = SI.GRAM;
				break;
			case 2:
				unitto = SI.KILOGRAM;
				break;
			case 3:
				unitto = NonSI.METRIC_TON;
				break;
			case 4:
				unitto = NonSI.TON_US;
				break;
			case 5:
				unitto = NonSI.TON_UK;
				break;
			case 6:
				unitto = SI.GRAM.divide((double)1/500);
				break;
			case 7:
				unitto = NonSI.OUNCE;
				break;
			case 8:
				unitto = NonSI.POUND;
				break;
			case 9:
				unitto = NonSI.POUND.divide((double)1/14);
				break;
			}
		 	break;
		 	
		case 5:
			switch(from) {
			case 0:
				unitfrom = SI.CELSIUS;			// Celsius
				break;
			case 1:
				unitfrom = SI.KELVIN;			// Kelvin
				break;
			case 2:
				unitfrom = NonSI.FAHRENHEIT;	// Fahrenheit
				break;
		 	}
		 	switch(to) {
			case 0:
				unitto = SI.CELSIUS;
				break;
			case 1:
				unitto = SI.KELVIN;
				break;
			case 2:
				unitto = NonSI.FAHRENHEIT;
				break;
			}
		 	break;
		 	
		case 6:
			switch(from) {
			case 0:
				unitfrom = SI.PASCAL.divide((double)1/100);		// millibar
				break;
			case 1:
				unitfrom = NonSI.BAR;					// bar
				break;
			case 2:
				unitfrom = SI.PASCAL;					// pascal
				break;
			case 3:
				unitfrom = SI.PASCAL.divide((double)1/100);		// hectopascal
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.PASCAL.divide((double)1/100);
				break;
			case 1:
				unitto = NonSI.BAR;
				break;
			case 2:
				unitto = SI.PASCAL;
				break;
			case 3:
				unitto = SI.PASCAL.divide((double)1/100);
				break;
			}
		 	break;
		 	
		case 7:
			switch(from) {
			case 0:
				unitfrom = SI.JOULE;						// joule
				break;
			case 1:
				unitfrom = SI.JOULE.divide((double)1/1000);			// kilojoule
				break;
			case 2:
				unitfrom = SI.JOULE.divide((double)0.239);			// calorie
				break;
			case 3:
				unitfrom = SI.JOULE.divide((double)0.000239);		// kilocalorie
				break;
			case 4:
				unitfrom = SI.JOULE;						// wattsecond
				break;
			case 5:
				unitfrom = SI.JOULE.divide((double)0.0000002778);	// kilowattsecond
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.JOULE;
				break;
			case 1:
				unitto = SI.JOULE.divide((double)1/1000);
				break;
			case 2:
				unitto = SI.JOULE.divide((double)0.239);
				break;
			case 3:
				unitto = SI.JOULE.divide((double)0.000239);
				break;
			case 4:
				unitto = SI.JOULE;
				break;
			case 5:
				unitto = SI.JOULE.divide((double)0.0000002778);
				break;
			}
		 	break;
		 	
		case 8:
			switch(from) {
			case 0:
				unitfrom = SI.WATT;					// watt
				break;
			case 1:
				unitfrom = SI.WATT.divide((double)1/1000);	// kilowatt
				break;
			case 2:
				unitfrom = NonSI.HORSEPOWER;		// horsepower
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.WATT;
				break;
			case 1:
				unitto = SI.WATT.divide((double)1/1000);
				break;
			case 2:
				unitto = NonSI.HORSEPOWER;
				break;
			}
			break;
			
		case 9:
			switch(from) {
			case 0:
				unitfrom = SI.SECOND;				// second
				break;
			case 1:
				unitfrom = NonSI.MINUTE;			// minute
				break;
			case 2:
				unitfrom = NonSI.HOUR;				// hour
				break;
			case 3:
				unitfrom = NonSI.DAY;				// day
				break;
			case 4:
				unitfrom = NonSI.WEEK;				// week
				break;
			case 5:
				unitfrom = NonSI.MONTH;				// month
				break;
			case 6:
				unitfrom = NonSI.YEAR_CALENDAR;		// year
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.SECOND;
				break;
			case 1:
				unitto = NonSI.MINUTE;
				break;
			case 2:
				unitto = NonSI.HOUR;
				break;
			case 3:
				unitto = NonSI.DAY;
				break;
			case 4:
				unitto = NonSI.WEEK;
				break;
			case 5:
				unitto = NonSI.MONTH;
				break;
			case 6:
				unitto = NonSI.YEAR_CALENDAR;
				break;
			}
		 	break;
		 	
		case 10:
			switch(from) {
			case 0:
				try {
					numberfrom = Integer.parseInt(_value,2);		// binary to decimal
				} catch (Exception e) {
					numerals = false;								// wrong input
				}
				break;
			case 1:
				try {
					numberfrom = Integer.parseInt(_value,8);		// octal to decimal
				} catch (Exception e) {
					numerals = false;								// wrong input
				}
				break;
			case 2:
				numberfrom = (int)value;
				break;
			case 3:
				try {
					numberfrom = Integer.parseInt(_value,16);		// hexadecimal to decimal
				} catch (Exception e) {
					numerals = false;								// wrong input
				}
				break;
			default:
				numberfrom = 1;
				break;
			}
			if (numerals == true) {
				switch(to) {
				case 0:
					numberto = Integer.toBinaryString(numberfrom);	// decimal to binary
					break;
				case 1:
					numberto = Integer.toOctalString(numberfrom);	// decimal to octal
					break;
				case 2:
					numberto = "" + numberfrom;						// decimal to decimal
					break;
				case 3:
					numberto = Integer.toHexString(numberfrom);		// decimal to hexadecimal
					break;
				}
			}		 	 
			break;
			
		case 11:
			switch(from) {
			case 0:
				unitfrom = SI.BIT;										// Bit
				break;
			case 1:
				unitfrom = SI.BIT.divide((double)1/1024);				// Kilobit
				break;
			case 2:
				unitfrom = SI.BIT.divide((double)1/1048576);			// Megabit
				break;
			case 3:
				unitfrom = SI.BIT.divide((double)1/1073741824);		// Gigabit
				break;
			case 4:
				unitfrom = SI.BIT.divide((double)1/1099511627776.0);	// Terabit
				break;
			case 5:
				unitfrom = NonSI.BYTE;									// Byte
				break;
			case 6:
				unitfrom = NonSI.BYTE.divide((double)1/1024);			// Kilobyte
				break;
			case 7:
				unitfrom = NonSI.BYTE.divide((double)1/1048576);		// Megabyte
				break;
			case 8:
				unitfrom = NonSI.BYTE.divide((double)1/1073741824);	// Gigabyte
				break;
			case 9:
				unitfrom = NonSI.BYTE.divide((double)1/1099511627776.0);// Terabyte
				break;
			}
			switch(to) {
			case 0:
				unitto = SI.BIT;										// Bit
				break;
			case 1:
				unitto = SI.BIT.divide((double)1/1024);				// Kilobit
				break;
			case 2:
				unitto = SI.BIT.divide((double)1/1048576);				// Megabit
				break;
			case 3:
				unitto = SI.BIT.divide((double)1/1073741824);			// Gigabit
				break;
			case 4:		
				unitto = SI.BIT.divide((double)1/1099511627776.0);		// Terabit
				break;
			case 5:
				unitto = NonSI.BYTE;									// Byte
				break;
			case 6:
				unitto = NonSI.BYTE.divide((double)1/1024);			// Kilobyte
				break;
			case 7:
				unitto = NonSI.BYTE.divide((double)1/1048576);			// Megabyte
				break;
			case 8:
				unitto = NonSI.BYTE.divide((double)1/1073741824);		// Gigabyte
				break;
			case 9:
				unitto = NonSI.BYTE.divide((double)1/1099511627776.0);	// Terabyte
				break;
			}
			break;
		 	
		case 12:
			switch(from) {
			case 0:
				shoe = ((double)(value/1.5)-1.5);				// shoe size [Europe] to centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 1:
				shoe = ((double)((double)(value+22)/3)*2.54);	// shoe size [Male(US)] to centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 2:
				shoe = ((double)((double)(value+21)/3)*2.54);	// shoe size [Female(US)] to centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 3:
				shoe = ((double)((double)(value+23)/3)*2.54);	// shoe size [Male(UK)] to centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 4:
				shoe = ((double)((double)(value+23)/3)*2.54);	// shoe size [Female(UK)] to centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 5:
				shoe = value;									// centimetre
				unitfrom = SI.CENTIMETRE;
				break;
			case 6:
				shoe = value;									// inch
				unitfrom = NonSI.INCH;
				break;
			}
			switch(to) {
			case 0:
				shoe = (double)((shoe+1.5)*1.5);				// centimetre to shoe size [Europe]
				unitto = SI.CENTIMETRE;
				break;
			case 1:
				shoe = (double)((double)(shoe/2.54)*3)-22;		// centimetre to shoe size [Male(US)]
				unitto = SI.CENTIMETRE;
				break;
			case 2:
				shoe = (double)((double)(shoe/2.54)*3)-21;		// centimetre to shoe size [Female(US)]
				unitto = SI.CENTIMETRE;
				break;
			case 3:
				shoe = (double)((double)(shoe/2.54)*3)-23;		// centimetre to shoe size [Male(UK)]
				unitto = SI.CENTIMETRE;
				break;
			case 4:
				shoe = (double)((double)(shoe/2.54)*3)-23;		// centimetre to shoe size [Female(UK)]
				unitto = SI.CENTIMETRE;
				break;
			case 5:
				unitto = SI.CENTIMETRE;
				break;
			case 6:
				unitto = NonSI.INCH;
				break;
			}
			break;
		}
	 	
	 	// shoe size
		if (topic == 12) {
			if (unitto.isCompatible(unitfrom)) {
				UnitConverter conv = unitfrom.getConverterTo(unitto);
				out.println("<p>" + _value + "</p>");
				out.println("<p>" + units[topic][from] + "</p>");
				out.println("<p>= " + conv.convert(shoe) + "</p>");
				out.println("<p>" + units[topic][to] + "</p>");
				%>
				<form method="get" action="index.jsp" accept-charset="UTF-8">
				<input type="submit" value="New"/>
				</form>
				<%
			}
		}
	 	
		// SI / NonSI units
		else if (topic != 10) {
			if (unitto.isCompatible(unitfrom)) {
				UnitConverter conv = unitfrom.getConverterTo(unitto);
				out.println("<p>" + _value + "</p>");
				out.println("<p>" + units[topic][from] + "</p>");
				out.println("<p>= " + conv.convert(value) + "</p>");
				out.println("<p>" + units[topic][to] + "</p>");
				%>
				<form method="get" action="index.jsp" accept-charset="UTF-8">
				<input type="submit" value="New"/>
				</form>
				<%
			}
		}
	 	
		// numerals
		else if (numerals == true){
			out.println("<p>" + _value + "</p>");
			out.println("<p>" + units[topic][from] + "</p>");
			out.println("<p>= " + numberto + "</p>");
			out.println("<p>" + units[topic][to] + "</p>");
			%>
			<form method="get" action="index.jsp" accept-charset="UTF-8">
			<input type="submit" value="New"/>
			</form>
			<%
		}
	 	
		// numerals error
		else if (numerals == false){
			out.println("<br />");
			out.println("<p style=\"text-align:center\">Invalid input!</p>");
		}
		else {
			out.println("<br />");
			out.println("<p style=\"text-align:center\">Invalid input!</p>");
		}
	 }
	
	// error
	else {
		out.println("<br />");
		out.println("<p style=\"text-align:center\">Invalid input!</p>");
	}
%>
</body>
</html>