<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html PUBLIC "-//OMA//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<%@ page language="java" 
		 contentType="text/html; charset=UTF-8"
		 pageEncoding="UTF-8"
		 import="unit.UnitNames"
%><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Convert to</title>
</head>
<body>
<ul>
<%
	//loading units...
	String[][] units = UnitNames.getUnits();

	// getting parameters...
	int topic;
	try {
		topic = Integer.parseInt(request.getParameter("topic"));
	} catch (NumberFormatException e) {
		topic = 0;
	}
	
	// writing units from selected topic in menu...	
	for(int i=0;i<units[topic].length;i++) {
		out.println("<li><a href=\"convertto.jsp?topic=" + topic + "&from=" + i +"\">" + units[topic][i] + "</a></li>");
	}
%>
</ul>
</body>
</html>